<?php if (!defined('BASEPATH')) exit('No direct script access allowed'); ?>
<!-- Bootstrap -->

<link rel="stylesheet" type="text/css" href="<?php echo base_url('assets/dist/fonts/font-awesome/css/font-awesome.css'); ?>">
<link rel="stylesheet" type="text/css" href="<?php echo base_url('assets/dist/css/bootstrap.css'); ?>">

<!-- Stylesheet
   ================================================== -->
<link rel="stylesheet" type="text/css" href="<?php echo base_url('assets/dist/css/custom.css'); ?>">

<div>
    <?php echo $_site_content;?>
</div>
