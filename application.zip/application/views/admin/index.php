<!-- Content Header (Page header) -->
<!-- Main content -->
<section class="content">
	<div>Selamat datang <?php echo $this->session->userdata('ses_user_name');?></div>

    <!-- Your Page Content Here -->
    <div class="box">
        <div class="box box-default">
            <div class="box-header with-border">
                <h3 class="box-title">Menu</h3>
                <div class="box-tools pull-right">
                    <button class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus">-</i></button>
                </div>
            </div>

            <div class="box-body">                
            </div> <!--end div body-->
        </div> <!--end box devault-->
    </div>
	<?php
	//print_r($pengguna);
	?>
</section><!-- /.content -->




